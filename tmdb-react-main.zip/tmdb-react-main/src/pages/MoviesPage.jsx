import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Spin, Typography } from 'antd';
import MovieList from '../components/movieList.jsx';

const { Title } = Typography;

const MoviesPage = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const res = await axios.get('http://localhost:8080/movies');
        const data = Array.isArray(res.data) ? res.data : res.data.data || [];
        setMovies(data);
      } catch (err) {
        console.error('Failed to fetch movies:', err);
        setMovies([]); // fallback untuk menghindari .map error
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  return (
    <div style={{ padding: '24px' }}>
      <Title level={2}>Movie List</Title>
      {loading ? <Spin size="large" /> : <MovieList movies={movies} />}
    </div>
  );
};

export default MoviesPage;
