import React from 'react';
import { Card, Col, Row, Rate } from 'antd';

const { Meta } = Card;

const MovieList = ({ movies }) => {
  return (
    <Row gutter={[16, 16]}>
      {movies.map(movie => (
        <Col xs={24} sm={12} md={8} lg={6} key={movie._id}>
          <Card
            hoverable
            cover={<img alt={movie.title} src={movie.poster || 'https://via.placeholder.com/300x400'} />}
          >
            <Meta title={movie.title} description={movie.description?.substring(0, 100) + '...'} />
            <div style={{ marginTop: '10px' }}>
              <strong>Rating:</strong>
              <br />
              <Rate disabled allowHalf defaultValue={movie.averageRating || 0} />
            </div>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default MovieList;
